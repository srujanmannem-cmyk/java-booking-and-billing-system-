package com.bookwise.booking;
import java.time.*; 
public record Booking(Long id,Long customerId,String customerName,Long serviceId,String serviceName,
 LocalDate bookingDate,String timeSlot,String status,String notes,LocalDateTime createdAt) {}
