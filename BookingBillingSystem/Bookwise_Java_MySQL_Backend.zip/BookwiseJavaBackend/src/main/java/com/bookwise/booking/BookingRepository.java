package com.bookwise.booking;
import org.springframework.jdbc.core.*;import org.springframework.stereotype.Repository;import java.util.*;
@Repository
public class BookingRepository {
 private final JdbcTemplate jdbc;
 private final RowMapper<Booking> mapper=(r,n)->new Booking(r.getLong("id"),r.getLong("customer_id"),r.getString("customer_name"),r.getLong("service_id"),r.getString("service_name"),r.getDate("booking_date").toLocalDate(),r.getString("time_slot"),r.getString("status"),r.getString("notes"),r.getTimestamp("created_at").toLocalDateTime());
 private final String SELECT="SELECT b.*,c.name customer_name,s.name service_name FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN services s ON s.id=b.service_id ";
 public BookingRepository(JdbcTemplate j){jdbc=j;}
 public List<Booking> all(){return jdbc.query(SELECT+"ORDER BY b.id DESC",mapper);}
 public Optional<Booking> get(long id){return jdbc.query(SELECT+"WHERE b.id=?",mapper,id).stream().findFirst();}
 public boolean slotTaken(long serviceId,java.time.LocalDate date,String slot){Integer n=jdbc.queryForObject("SELECT COUNT(*) FROM bookings WHERE service_id=? AND booking_date=? AND time_slot=? AND status='CONFIRMED'",Integer.class,serviceId,date,slot);return n!=null&&n>0;}
 public long insert(BookingRequest r){jdbc.update("INSERT INTO bookings(customer_id,service_id,booking_date,time_slot,notes) VALUES(?,?,?,?,?)",r.customerId(),r.serviceId(),r.bookingDate(),r.timeSlot().trim(),r.notes());return jdbc.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 public void update(long id,BookingRequest r){jdbc.update("UPDATE bookings SET customer_id=?,service_id=?,booking_date=?,time_slot=?,notes=? WHERE id=? AND status='CONFIRMED'",r.customerId(),r.serviceId(),r.bookingDate(),r.timeSlot().trim(),r.notes(),id);}
 public void cancel(long id){jdbc.update("UPDATE bookings SET status='CANCELLED' WHERE id=?",id);}
}
