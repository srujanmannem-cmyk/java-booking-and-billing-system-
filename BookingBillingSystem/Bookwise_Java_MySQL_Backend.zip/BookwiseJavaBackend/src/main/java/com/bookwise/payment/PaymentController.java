package com.bookwise.payment;
import jakarta.validation.Valid;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/payments")
public class PaymentController {
 private final PaymentService service;public PaymentController(PaymentService s){service=s;}
 @GetMapping public List<Payment> all(){return service.all();}
 @GetMapping("/{id}") public Payment get(@PathVariable long id){return service.get(id);}
 @GetMapping("/bill/{billId}") public List<Payment> byBill(@PathVariable long billId){return service.all().stream().filter(p->p.billId().equals(billId)).toList();}
 @PostMapping public Payment create(@Valid @RequestBody PaymentRequest r){return service.create(r);}
 @PutMapping("/{id}") public Payment update(@PathVariable long id,@Valid @RequestBody PaymentRequest r){return service.update(id,r);}
 @DeleteMapping("/{id}") public void delete(@PathVariable long id){service.delete(id);}
}
