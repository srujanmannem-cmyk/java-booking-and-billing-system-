package com.bookwise.payment;
import jakarta.validation.constraints.*;import java.math.BigDecimal;
public record PaymentRequest(@NotNull @Positive Long billId,@NotBlank String method,
 @NotNull @DecimalMin(value="0.01") BigDecimal amount,@Size(max=150) String referenceNote) {}
