package com.bookwise.service;
import java.math.BigDecimal;
public record ServiceItem(Long id,String name,String description,BigDecimal basePrice,boolean active) {}
