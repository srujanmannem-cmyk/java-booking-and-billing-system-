package com.bookwise.booking;
import com.bookwise.customer.CustomerService;import com.bookwise.service.ServiceCatalog;
import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import java.util.*;
@Service
public class BookingService {
 private final BookingRepository repo;private final CustomerService customers;private final ServiceCatalog services;
 public BookingService(BookingRepository r,CustomerService c,ServiceCatalog s){repo=r;customers=c;services=s;}
 public List<Booking> all(){return repo.all();}
 public Booking get(long id){return repo.get(id).orElseThrow(()->new NoSuchElementException("Booking not found: "+id));}
 @Transactional public Booking create(BookingRequest r){customers.get(r.customerId());var service=services.get(r.serviceId());if(!service.active())throw new IllegalArgumentException("Selected service is inactive");if(repo.slotTaken(r.serviceId(),r.bookingDate(),r.timeSlot().trim()))throw new IllegalArgumentException("This time slot is already booked");return get(repo.insert(r));}
 @Transactional public Booking update(long id,BookingRequest r){get(id);customers.get(r.customerId());services.get(r.serviceId());if(repo.slotTaken(r.serviceId(),r.bookingDate(),r.timeSlot().trim())){Booking old=get(id);if(!(old.serviceId().equals(r.serviceId())&&old.bookingDate().equals(r.bookingDate())&&old.timeSlot().equals(r.timeSlot())))throw new IllegalArgumentException("This time slot is already booked");}repo.update(id,r);return get(id);}
 public void cancel(long id){get(id);repo.cancel(id);}
}
