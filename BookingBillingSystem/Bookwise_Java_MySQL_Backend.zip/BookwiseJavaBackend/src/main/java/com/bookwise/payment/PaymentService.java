package com.bookwise.payment;
import com.bookwise.billing.BillService;import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import java.math.*;import java.util.*;
@Service
public class PaymentService {
 private final PaymentRepository repo;private final BillService bills;
 public PaymentService(PaymentRepository r,BillService b){repo=r;bills=b;}
 public List<Payment> all(){return repo.all();}
 public Payment get(long id){return repo.get(id).orElseThrow(()->new NoSuchElementException("Payment not found: "+id));}
 private String method(String raw){String m=raw.trim().toUpperCase(Locale.ROOT);if(!Set.of("CASH","CARD","UPI").contains(m))throw new IllegalArgumentException("Payment method must be CASH, CARD or UPI");return m;}
 @Transactional public Payment create(PaymentRequest r){var bill=bills.get(r.billId());BigDecimal paid=repo.totalForBill(r.billId());if(paid.add(r.amount()).compareTo(bill.totalAmount())>0)throw new IllegalArgumentException("Payment exceeds remaining bill balance");return get(repo.insert(r,method(r.method())));}
 @Transactional public Payment update(long id,PaymentRequest r){get(id);var bill=bills.get(r.billId());BigDecimal other=repo.totalForBill(r.billId());Payment old=get(id);if(old.billId().equals(r.billId()))other=other.subtract(old.amount());if(other.add(r.amount()).compareTo(bill.totalAmount())>0)throw new IllegalArgumentException("Payment exceeds remaining bill balance");repo.update(id,r,method(r.method()));return get(id);}
 public void delete(long id){get(id);repo.delete(id);}
 public BigDecimal totalForBill(long billId){return repo.totalForBill(billId);}
}
