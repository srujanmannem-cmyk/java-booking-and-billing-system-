package com.bookwise.customer;
import jakarta.validation.constraints.*;
public record CustomerRequest(
 @NotBlank @Size(max=100) String name,
 @NotBlank @Pattern(regexp="^[+0-9\\s-]{8,20}$", message="Enter a valid phone number") String phone,
 @Email @Size(max=150) String email) {}
