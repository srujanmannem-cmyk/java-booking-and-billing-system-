package com.bookwise.service;
import jakarta.validation.Valid;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/services")
public class ServiceController {
 private final ServiceCatalog service;public ServiceController(ServiceCatalog s){service=s;}
 @GetMapping public List<ServiceItem> all(){return service.all();}
 @GetMapping("/{id}") public ServiceItem get(@PathVariable long id){return service.get(id);}
 @PostMapping public ServiceItem create(@Valid @RequestBody ServiceRequest r){return service.create(r);}
 @PutMapping("/{id}") public ServiceItem update(@PathVariable long id,@Valid @RequestBody ServiceRequest r){return service.update(id,r);}
 @DeleteMapping("/{id}") public void delete(@PathVariable long id){service.delete(id);}
}
