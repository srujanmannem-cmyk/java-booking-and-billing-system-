package com.bookwise.booking;
import jakarta.validation.Valid;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/bookings")
public class BookingController {
 private final BookingService service;public BookingController(BookingService s){service=s;}
 @GetMapping public List<Booking> all(){return service.all();}
 @GetMapping("/{id}") public Booking get(@PathVariable long id){return service.get(id);}
 @PostMapping public Booking create(@Valid @RequestBody BookingRequest r){return service.create(r);}
 @PutMapping("/{id}") public Booking update(@PathVariable long id,@Valid @RequestBody BookingRequest r){return service.update(id,r);}
 @PatchMapping("/{id}/cancel") public Map<String,String> cancel(@PathVariable long id){service.cancel(id);return Map.of("message","Booking cancelled");}
}
