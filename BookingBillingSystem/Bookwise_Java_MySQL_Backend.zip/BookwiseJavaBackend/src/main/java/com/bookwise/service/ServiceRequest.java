package com.bookwise.service;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
public record ServiceRequest(@NotBlank @Size(max=100) String name,@Size(max=500) String description,
 @NotNull @DecimalMin("0.00") BigDecimal basePrice, Boolean active) {}
