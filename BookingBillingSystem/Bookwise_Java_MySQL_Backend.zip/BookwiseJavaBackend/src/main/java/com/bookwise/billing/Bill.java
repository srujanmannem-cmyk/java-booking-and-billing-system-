package com.bookwise.billing;
import java.math.BigDecimal;import java.time.LocalDateTime;
public record Bill(Long id,Long bookingId,BigDecimal serviceCharge,BigDecimal additionalCharge,BigDecimal subtotal,
 BigDecimal discountPercent,BigDecimal discountAmount,BigDecimal taxPercent,BigDecimal taxAmount,BigDecimal totalAmount,LocalDateTime createdAt) {}
