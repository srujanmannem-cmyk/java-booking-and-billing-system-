package com.bookwise.billing;
import jakarta.validation.constraints.*;import java.math.BigDecimal;
public record BillRequest(@NotNull @Positive Long bookingId,@NotNull @DecimalMin("0.00") BigDecimal serviceCharge,
 @NotNull @DecimalMin("0.00") BigDecimal additionalCharge,@NotNull @DecimalMin("0.00") @DecimalMax("100.00") BigDecimal discountPercent,
 @NotNull @DecimalMin("0.00") @DecimalMax("100.00") BigDecimal taxPercent) {}
