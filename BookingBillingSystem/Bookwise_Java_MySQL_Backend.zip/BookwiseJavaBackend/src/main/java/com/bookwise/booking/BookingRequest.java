package com.bookwise.booking;
import jakarta.validation.constraints.*;import java.time.LocalDate;
public record BookingRequest(@NotNull @Positive Long customerId,@NotNull @Positive Long serviceId,
 @NotNull @FutureOrPresent LocalDate bookingDate,@NotBlank @Size(max=50) String timeSlot,@Size(max=500) String notes) {}
