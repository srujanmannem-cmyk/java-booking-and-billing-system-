package com.bookwise.customer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class CustomerRepository {
 private final JdbcTemplate jdbc;
 private final RowMapper<Customer> mapper=(rs,n)->new Customer(rs.getLong("id"),rs.getString("name"),rs.getString("phone"),rs.getString("email"));
 public CustomerRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
 public List<Customer> findAll(){return jdbc.query("SELECT * FROM customers ORDER BY id DESC",mapper);}
 public Optional<Customer> findById(long id){return jdbc.query("SELECT * FROM customers WHERE id=?",mapper,id).stream().findFirst();}
 public long save(CustomerRequest r){jdbc.update("INSERT INTO customers(name,phone,email) VALUES(?,?,?)",r.name().trim(),r.phone().trim(),r.email());return jdbc.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 public int update(long id,CustomerRequest r){return jdbc.update("UPDATE customers SET name=?,phone=?,email=? WHERE id=?",r.name().trim(),r.phone().trim(),r.email(),id);}
 public int delete(long id){return jdbc.update("DELETE FROM customers WHERE id=?",id);}
}
