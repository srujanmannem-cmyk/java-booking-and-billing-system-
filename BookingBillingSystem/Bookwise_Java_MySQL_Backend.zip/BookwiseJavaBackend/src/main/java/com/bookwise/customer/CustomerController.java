package com.bookwise.customer;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/customers")
public class CustomerController {
 private final CustomerService service;
 public CustomerController(CustomerService service){this.service=service;}
 @GetMapping public List<Customer> all(){return service.all();}
 @GetMapping("/{id}") public Customer get(@PathVariable long id){return service.get(id);}
 @PostMapping public Customer create(@Valid @RequestBody CustomerRequest r){return service.create(r);}
 @PutMapping("/{id}") public Customer update(@PathVariable long id,@Valid @RequestBody CustomerRequest r){return service.update(id,r);}
 @DeleteMapping("/{id}") public void delete(@PathVariable long id){service.delete(id);}
}
