package com.bookwise.service;
import org.springframework.stereotype.Service;import java.util.*;
@Service
public class ServiceCatalog {
 private final ServiceRepository repo;public ServiceCatalog(ServiceRepository r){repo=r;}
 public List<ServiceItem> all(){return repo.all();}
 public ServiceItem get(long id){return repo.get(id).orElseThrow(()->new NoSuchElementException("Service not found: "+id));}
 public ServiceItem create(ServiceRequest r){return get(repo.insert(r));}
 public ServiceItem update(long id,ServiceRequest r){get(id);repo.update(id,r);return get(id);}
 public void delete(long id){get(id);repo.delete(id);}
}
