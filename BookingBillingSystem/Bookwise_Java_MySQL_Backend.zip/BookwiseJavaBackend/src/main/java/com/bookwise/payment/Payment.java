package com.bookwise.payment;
import java.math.BigDecimal;import java.time.LocalDateTime;
public record Payment(Long id,Long billId,String method,BigDecimal amount,String referenceNote,LocalDateTime createdAt) {}
