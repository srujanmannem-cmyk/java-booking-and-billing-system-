package com.bookwise.billing;
import org.springframework.jdbc.core.*;import org.springframework.stereotype.Repository;import java.util.*;
@Repository
public class BillRepository {
 private final JdbcTemplate jdbc;private final RowMapper<Bill> mapper=(r,n)->new Bill(r.getLong("id"),r.getLong("booking_id"),r.getBigDecimal("service_charge"),r.getBigDecimal("additional_charge"),r.getBigDecimal("subtotal"),r.getBigDecimal("discount_percent"),r.getBigDecimal("discount_amount"),r.getBigDecimal("tax_percent"),r.getBigDecimal("tax_amount"),r.getBigDecimal("total_amount"),r.getTimestamp("created_at").toLocalDateTime());
 public BillRepository(JdbcTemplate j){jdbc=j;}
 public List<Bill> all(){return jdbc.query("SELECT * FROM bills ORDER BY id DESC",mapper);}
 public Optional<Bill> get(long id){return jdbc.query("SELECT * FROM bills WHERE id=?",mapper,id).stream().findFirst();}
 public Optional<Bill> byBooking(long id){return jdbc.query("SELECT * FROM bills WHERE booking_id=?",mapper,id).stream().findFirst();}
 public long insert(BillRequest r,java.math.BigDecimal subtotal,java.math.BigDecimal discount,java.math.BigDecimal tax,java.math.BigDecimal total){jdbc.update("INSERT INTO bills(booking_id,service_charge,additional_charge,subtotal,discount_percent,discount_amount,tax_percent,tax_amount,total_amount) VALUES(?,?,?,?,?,?,?,?,?)",r.bookingId(),r.serviceCharge(),r.additionalCharge(),subtotal,r.discountPercent(),discount,r.taxPercent(),tax,total);return jdbc.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 public void update(long id,BillRequest r,java.math.BigDecimal subtotal,java.math.BigDecimal discount,java.math.BigDecimal tax,java.math.BigDecimal total){jdbc.update("UPDATE bills SET service_charge=?,additional_charge=?,subtotal=?,discount_percent=?,discount_amount=?,tax_percent=?,tax_amount=?,total_amount=? WHERE id=?",r.serviceCharge(),r.additionalCharge(),subtotal,r.discountPercent(),discount,r.taxPercent(),tax,total,id);}
 public void delete(long id){jdbc.update("DELETE FROM bills WHERE id=?",id);}
}
