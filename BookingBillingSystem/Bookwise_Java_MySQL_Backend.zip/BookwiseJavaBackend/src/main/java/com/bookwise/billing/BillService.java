package com.bookwise.billing;
import com.bookwise.booking.BookingService;import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import java.math.*;import java.util.*;
@Service
public class BillService {
 private final BillRepository repo;private final BookingService bookings;
 public BillService(BillRepository r,BookingService b){repo=r;bookings=b;}
 public List<Bill> all(){return repo.all();}
 public Bill get(long id){return repo.get(id).orElseThrow(()->new NoSuchElementException("Bill not found: "+id));}
 private BigDecimal[] calculate(BillRequest r){BigDecimal hundred=new BigDecimal("100");BigDecimal subtotal=r.serviceCharge().add(r.additionalCharge());BigDecimal discount=subtotal.multiply(r.discountPercent()).divide(hundred,2,RoundingMode.HALF_UP);BigDecimal taxable=subtotal.subtract(discount);BigDecimal tax=taxable.multiply(r.taxPercent()).divide(hundred,2,RoundingMode.HALF_UP);BigDecimal total=taxable.add(tax);return new BigDecimal[]{subtotal,discount,tax,total};}
 @Transactional public Bill create(BillRequest r){bookings.get(r.bookingId());if(repo.byBooking(r.bookingId()).isPresent())throw new IllegalArgumentException("A bill already exists for this booking");BigDecimal[] x=calculate(r);return get(repo.insert(r,x[0],x[1],x[2],x[3]));}
 @Transactional public Bill update(long id,BillRequest r){Bill old=get(id);if(!old.bookingId().equals(r.bookingId()))throw new IllegalArgumentException("Bill cannot be moved to another booking");BigDecimal[] x=calculate(r);repo.update(id,r,x[0],x[1],x[2],x[3]);return get(id);}
 @Transactional public void delete(long id){get(id);repo.delete(id);}
}
