package com.bookwise.billing;
import jakarta.validation.Valid;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/bills")
public class BillController {
 private final BillService service;public BillController(BillService s){service=s;}
 @GetMapping public List<Bill> all(){return service.all();}
 @GetMapping("/{id}") public Bill get(@PathVariable long id){return service.get(id);}
 @PostMapping public Bill create(@Valid @RequestBody BillRequest r){return service.create(r);}
 @PutMapping("/{id}") public Bill update(@PathVariable long id,@Valid @RequestBody BillRequest r){return service.update(id,r);}
 @DeleteMapping("/{id}") public void delete(@PathVariable long id){service.delete(id);}
}
