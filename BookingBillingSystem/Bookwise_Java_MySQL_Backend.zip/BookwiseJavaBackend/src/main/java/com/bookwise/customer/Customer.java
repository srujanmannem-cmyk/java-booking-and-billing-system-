package com.bookwise.customer;
public record Customer(Long id, String name, String phone, String email) {}
