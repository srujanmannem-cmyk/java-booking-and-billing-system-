package com.bookwise.customer;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class CustomerService {
 private final CustomerRepository repo;
 public CustomerService(CustomerRepository repo){this.repo=repo;}
 public List<Customer> all(){return repo.findAll();}
 public Customer get(long id){return repo.findById(id).orElseThrow(()->new NoSuchElementException("Customer not found: "+id));}
 public Customer create(CustomerRequest r){return get(repo.save(r));}
 public Customer update(long id,CustomerRequest r){get(id);repo.update(id,r);return get(id);}
 public void delete(long id){get(id);repo.delete(id);}
}
