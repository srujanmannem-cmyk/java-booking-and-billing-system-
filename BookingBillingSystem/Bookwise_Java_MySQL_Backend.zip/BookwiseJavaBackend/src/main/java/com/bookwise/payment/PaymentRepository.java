package com.bookwise.payment;
import org.springframework.jdbc.core.*;import org.springframework.stereotype.Repository;import java.util.*;
@Repository
public class PaymentRepository {
 private final JdbcTemplate jdbc;private final RowMapper<Payment> mapper=(r,n)->new Payment(r.getLong("id"),r.getLong("bill_id"),r.getString("method"),r.getBigDecimal("amount"),r.getString("reference_note"),r.getTimestamp("created_at").toLocalDateTime());
 public PaymentRepository(JdbcTemplate j){jdbc=j;}
 public List<Payment> all(){return jdbc.query("SELECT * FROM payments ORDER BY id DESC",mapper);}
 public Optional<Payment> get(long id){return jdbc.query("SELECT * FROM payments WHERE id=?",mapper,id).stream().findFirst();}
 public List<Payment> byBill(long id){return jdbc.query("SELECT * FROM payments WHERE bill_id=? ORDER BY id DESC",mapper,id);}
 public long insert(PaymentRequest r,String method){jdbc.update("INSERT INTO payments(bill_id,method,amount,reference_note) VALUES(?,?,?,?)",r.billId(),method,r.amount(),r.referenceNote());return jdbc.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 public void update(long id,PaymentRequest r,String method){jdbc.update("UPDATE payments SET bill_id=?,method=?,amount=?,reference_note=? WHERE id=?",r.billId(),method,r.amount(),r.referenceNote(),id);}
 public void delete(long id){jdbc.update("DELETE FROM payments WHERE id=?",id);}
 public java.math.BigDecimal totalForBill(long billId){return jdbc.queryForObject("SELECT COALESCE(SUM(amount),0) FROM payments WHERE bill_id=?",java.math.BigDecimal.class,billId);}
}
