package com.bookwise.service;
import org.springframework.jdbc.core.*;import org.springframework.stereotype.Repository;import java.util.*;
@Repository
public class ServiceRepository {
 private final JdbcTemplate jdbc;
 private final RowMapper<ServiceItem> mapper=(r,n)->new ServiceItem(r.getLong("id"),r.getString("name"),r.getString("description"),r.getBigDecimal("base_price"),r.getBoolean("active"));
 public ServiceRepository(JdbcTemplate j){jdbc=j;}
 public List<ServiceItem> all(){return jdbc.query("SELECT * FROM services ORDER BY id",mapper);}
 public Optional<ServiceItem> get(long id){return jdbc.query("SELECT * FROM services WHERE id=?",mapper,id).stream().findFirst();}
 public long insert(ServiceRequest r){jdbc.update("INSERT INTO services(name,description,base_price,active) VALUES(?,?,?,?)",r.name().trim(),r.description(),r.basePrice(),r.active()==null?true:r.active());return jdbc.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 public void update(long id,ServiceRequest r){jdbc.update("UPDATE services SET name=?,description=?,base_price=?,active=? WHERE id=?",r.name().trim(),r.description(),r.basePrice(),r.active()==null?true:r.active(),id);}
 public void delete(long id){jdbc.update("DELETE FROM services WHERE id=?",id);}
}
